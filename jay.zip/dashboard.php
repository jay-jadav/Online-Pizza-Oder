<?php include('auth.php'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="dashboard">
    <h1>Welcome, Admin</h1>
    <a href="orders.php" class="btn">View Orders</a>
    <a href="logout.php" class="btn logout">Logout</a>
</div>
</body>
</html>
