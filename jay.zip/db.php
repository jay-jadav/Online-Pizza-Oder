<?php
$servername= "localhost";
$dbname = "pizza";
$username = "root";
$password = ""; // or your MySQL password

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>