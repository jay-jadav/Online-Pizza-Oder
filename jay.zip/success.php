<!DOCTYPE html>
<html>
<head>
<title>Order Successful</title>
<style>
body { font-family: Arial; background: #fff8f0; text-align: center; padding: 50px; }
h2 { color: green; }
a { display: inline-block; margin-top: 20px; padding: 10px 20px; background: #ff6347; color: white; text-decoration: none; border-radius: 5px; }
a:hover { background: darkred; }
</style>
</head>
<body>

<h2>✅ Your order has been placed successfully!</h2>
<p>We will contact you soon for delivery.</p>
<a href="menu.php">Back to Menu</a>

</body>
</html>
